// Global variables
let selectedCell = null;
let currentBoard = Array(9).fill().map(() => Array(9).fill(0));
let originalBoard = Array(9).fill().map(() => Array(9).fill(0));
let customBoard = Array(9).fill().map(() => Array(9).fill(0));
let timerInterval = null;
let startTime = null;

// Initialize the game
document.addEventListener('DOMContentLoaded', function() {
    createBoard('sudoku-board');
    createBoard('custom-board');
    
    // Generate a puzzle on load
    generatePuzzle();
});

// Tab functionality
function openTab(tabId) {
    // Hide all tab contents
    const tabContents = document.querySelectorAll('.tab-content');
    tabContents.forEach(tab => tab.classList.remove('active'));
    
    // Deactivate all tab buttons
    const tabButtons = document.querySelectorAll('.tab-button');
    tabButtons.forEach(button => button.classList.remove('active'));
    
    // Show the selected tab content
    document.getElementById(tabId).classList.add('active');
    
    // Activate the clicked tab button
    event.currentTarget.classList.add('active');
}

// Create the Sudoku board
function createBoard(boardId) {
    const board = document.getElementById(boardId);
    board.innerHTML = '';
    
    for (let row = 0; row < 9; row++) {
        for (let col = 0; col < 9; col++) {
            const cell = document.createElement('div');
            cell.className = 'cell';
            cell.dataset.row = row;
            cell.dataset.col = col;
            
            // Add event listener to the cell
            cell.addEventListener('click', function() {
                if (boardId === 'sudoku-board') {
                    selectCell(this);
                } else {
                    selectCustomCell(this);
                }
            });
            
            board.appendChild(cell);
        }
    }
}

// Select a cell on the play board
function selectCell(cell) {
    // Check if the cell is fixed (part of the original puzzle)
    if (cell.classList.contains('fixed')) {
        return;
    }
    
    // Remove the selected class from the previously selected cell
    if (selectedCell) {
        selectedCell.classList.remove('selected');
    }
    
    // Select the new cell
    cell.classList.add('selected');
    selectedCell = cell;
}

// Select a cell on the custom board
function selectCustomCell(cell) {
    // Remove the selected class from the previously selected cell
    const prevSelected = document.querySelector('#custom-board .cell.selected');
    if (prevSelected) {
        prevSelected.classList.remove('selected');
    }
    
    // Select the new cell
    cell.classList.add('selected');
}

// Set a number in the selected cell
function selectNumber(number) {
    if (!selectedCell) return;
    
    const row = parseInt(selectedCell.dataset.row);
    const col = parseInt(selectedCell.dataset.col);
    
    // Update the board array
    currentBoard[row][col] = number;
    
    // Update the cell text
    selectedCell.textContent = number === 0 ? '' : number;
    
    // Check if the number is valid
    if (number !== 0 && !isValidPlacement(currentBoard, row, col, number)) {
        selectedCell.classList.add('invalid');
    } else {
        selectedCell.classList.remove('invalid');
    }
}

// Set a number in the selected custom cell
function selectCustomNumber(number) {
    const selectedCell = document.querySelector('#custom-board .cell.selected');
    if (!selectedCell) return;
    
    const row = parseInt(selectedCell.dataset.row);
    const col = parseInt(selectedCell.dataset.col);
    
    // Update the board array
    customBoard[row][col] = number;
    
    // Update the cell text
    selectedCell.textContent = number === 0 ? '' : number;
}

// Check if a number placement is valid
function isValidPlacement(board, row, col, num) {
    // Check row
    for (let x = 0; x < 9; x++) {
        if (x !== col && board[row][x] === num) {
            return false;
        }
    }
    
    // Check column
    for (let x = 0; x < 9; x++) {
        if (x !== row && board[x][col] === num) {
            return false;
        }
    }
    
    // Check 3x3 box
    const boxRow = Math.floor(row / 3) * 3;
    const boxCol = Math.floor(col / 3) * 3;
    
    for (let i = 0; i < 3; i++) {
        for (let j = 0; j < 3; j++) {
            const r = boxRow + i;
            const c = boxCol + j;
            if (r !== row || c !== col) {
                if (board[r][c] === num) {
                    return false;
                }
            }
        }
    }
    
    return true;
}

// Generate a new Sudoku puzzle
function generatePuzzle() {
    const difficulty = document.getElementById('difficulty').value;
    
    // Clear message
    document.getElementById('message').textContent = '';
    document.getElementById('message').className = 'message';
    
    // Reset timer
    if (timerInterval) {
        clearInterval(timerInterval);
    }
    document.getElementById('timer').textContent = '00:00';
    
    // Show loading message
    const messageEl = document.getElementById('message');
    messageEl.textContent = 'Generating puzzle...';
    messageEl.className = 'message info';
    
    // Send request to generate a new puzzle
    fetch('/generate', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `difficulty=${difficulty}`
    })
    .then(response => response.json())
    .then(data => {
        // Update the board
        currentBoard = data.board;
        originalBoard = JSON.parse(JSON.stringify(data.board));
        
        // Display the board
        updateBoardDisplay();
        
        // Start the timer
        startTimer();
        
        // Show message
        messageEl.textContent = data.message;
    })
    .catch(error => {
        console.error('Error:', error);
        messageEl.textContent = 'Error generating puzzle. Please try again.';
        messageEl.className = 'message error';
    });
}

// Update the board display
function updateBoardDisplay() {
    const cells = document.querySelectorAll('#sudoku-board .cell');
    
    cells.forEach(cell => {
        const row = parseInt(cell.dataset.row);
        const col = parseInt(cell.dataset.col);
        const value = currentBoard[row][col];
        
        cell.textContent = value === 0 ? '' : value;
        
        // Mark original cells as fixed
        if (originalBoard[row][col] !== 0) {
            cell.classList.add('fixed');
        } else {
            cell.classList.remove('fixed');
        }
        
        cell.classList.remove('invalid');
        cell.classList.remove('selected');
    });
    
    selectedCell = null;
}

// Start the timer
function startTimer() {
    startTime = new Date();
    
    if (timerInterval) {
        clearInterval(timerInterval);
    }
    
    timerInterval = setInterval(function() {
        const currentTime = new Date();
        const elapsedTime = Math.floor((currentTime - startTime) / 1000);
        
        const minutes = Math.floor(elapsedTime / 60).toString().padStart(2, '0');
        const seconds = (elapsedTime % 60).toString().padStart(2, '0');
        
        document.getElementById('timer').textContent = `${minutes}:${seconds}`;
    }, 1000);
}

// Check if the solution is correct
function checkSolution() {
    // Check if the board is complete
    let isComplete = true;
    for (let row = 0; row < 9; row++) {
        for (let col = 0; col < 9; col++) {
            if (currentBoard[row][col] === 0) {
                isComplete = false;
                break;
            }
        }
        if (!isComplete) break;
    }
    
    if (!isComplete) {
        const messageEl = document.getElementById('message');
        messageEl.textContent = 'Please complete the puzzle before checking.';
        messageEl.className = 'message error';
        return;
    }
    
    // Send request to check the solution
    fetch('/solve', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            board: currentBoard
        })
    })
    .then(response => response.json())
    .then(data => {
        const messageEl = document.getElementById('message');
        
        if (data.is_correct) {
            // Stop the timer
            clearInterval(timerInterval);
            
            messageEl.textContent = `${data.message} Time: ${data.time_taken} seconds.`;
            messageEl.className = 'message success';
        } else {
            messageEl.textContent = data.message;
            messageEl.className = 'message error';
            
            // Highlight errors
            highlightErrors(data.solution);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        const messageEl = document.getElementById('message');
        messageEl.textContent = 'Error checking solution. Please try again.';
        messageEl.className = 'message error';
    });
}

// Highlight errors in the solution
function highlightErrors(solution) {
    const cells = document.querySelectorAll('#sudoku-board .cell');
    
    cells.forEach(cell => {
        const row = parseInt(cell.dataset.row);
        const col = parseInt(cell.dataset.col);
        
        if (currentBoard[row][col] !== solution[row][col]) {
            cell.classList.add('invalid');
        } else {
            cell.classList.remove('invalid');
        }
    });
}

// Solve the puzzle
function solvePuzzle() {
    // Send request to solve the puzzle
    fetch('/solve', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            board: currentBoard
        })
    })
    .then(response => response.json())
    .then(data => {
        // Update the board with the solution
        currentBoard = data.solution;
        updateBoardDisplay();
        
        // Stop the timer
        clearInterval(timerInterval);
        
        // Show message
        const messageEl = document.getElementById('message');
        messageEl.textContent = data.message;
        messageEl.className = 'message info';
    })
    .catch(error => {
        console.error('Error:', error);
        const messageEl = document.getElementById('message');
        messageEl.textContent = 'Error solving puzzle. Please try again.';
        messageEl.className = 'message error';
    });
}

// Clear the custom board
function clearCustomBoard() {
    customBoard = Array(9).fill().map(() => Array(9).fill(0));
    
    const cells = document.querySelectorAll('#custom-board .cell');
    cells.forEach(cell => {
        cell.textContent = '';
        cell.classList.remove('selected');
    });
    
    document.getElementById('custom-message').textContent = '';
    document.getElementById('custom-message').className = 'message';
}

// Check and solve the custom puzzle
function checkCustomPuzzle() {
    // Send request to check and solve the custom puzzle
    fetch('/check_custom', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            board: customBoard
        })
    })
    .then(response => response.json())
    .then(data => {
        const messageEl = document.getElementById('custom-message');
        
        if (data.is_valid) {
            // Update the board with the solution
            const cells = document.querySelectorAll('#custom-board .cell');
            
            cells.forEach(cell => {
                const row = parseInt(cell.dataset.row);
                const col = parseInt(cell.dataset.col);
                
                // Only update cells that were empty
                if (customBoard[row][col] === 0) {
                    cell.textContent = data.solution[row][col];
                }
            });
            
            messageEl.textContent = data.message;
            messageEl.className = 'message success';
        } else {
            messageEl.textContent = data.message;
            messageEl.className = 'message error';
        }
    })
    .catch(error => {
        console.error('Error:', error);
        const messageEl = document.getElementById('custom-message');
        messageEl.textContent = 'Error checking puzzle. Please try again.';
        messageEl.className = 'message error';
    });
}