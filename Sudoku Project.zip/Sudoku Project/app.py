from flask import Flask, render_template, request, jsonify, session
import random
import time
import copy
import secrets

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)

def generate_sudoku(difficulty=0.5):
    # Start with a solved board
    board = [[0 for _ in range(9)] for _ in range(9)]
    # Fill the diagonal boxes first
    for box in range(0, 9, 3):
        fill_box(board, box, box)
    # Solve the rest of the board
    solve_sudoku(board)
    
    # Create a copy of the solved board
    solution = copy.deepcopy(board)
    
    # Remove numbers based on difficulty
    cells_to_remove = int(81 * difficulty)
    while cells_to_remove > 0:
        row = random.randint(0, 8)
        col = random.randint(0, 8)
        if board[row][col] != 0:
            board[row][col] = 0
            cells_to_remove -= 1
    
    return board, solution

def fill_box(board, row, col):
    """Fill a 3x3 box with random numbers"""
    nums = list(range(1, 10))
    random.shuffle(nums)
    for i in range(3):
        for j in range(3):
            board[row + i][col + j] = nums.pop()

def is_valid(board, row, col, num):
    """Check if a number is valid in the given position"""
    # Check row
    for x in range(9):
        if board[row][x] == num:
            return False
    
    # Check column
    for x in range(9):
        if board[x][col] == num:
            return False
    
    # Check 3x3 box
    start_row, start_col = 3 * (row // 3), 3 * (col // 3)
    for i in range(3):
        for j in range(3):
            if board[start_row + i][start_col + j] == num:
                return False
    
    return True

def find_empty(board):
    """Find an empty cell in the board"""
    for i in range(9):
        for j in range(9):
            if board[i][j] == 0:
                return (i, j)
    return None

def solve_sudoku(board):
    """Solve the Sudoku board using backtracking"""
    empty = find_empty(board)
    if not empty:
        return True
    
    row, col = empty
    for num in range(1, 10):
        if is_valid(board, row, col, num):
            board[row][col] = num
            if solve_sudoku(board):
                return True
            board[row][col] = 0
    
    return False

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/generate', methods=['POST'])
def generate():
    difficulty = float(request.form.get('difficulty', 0.5))
    board, solution = generate_sudoku(difficulty)
    
    # Store the solution and the start time in the session
    session['solution'] = solution
    session['start_time'] = time.time()
    
    return jsonify({
        'board': board,
        'message': 'Sudoku puzzle generated!'
    })

@app.route('/solve', methods=['POST'])
def solve():
    user_board = request.json.get('board')
    
    if 'solution' in session:
        # Calculate the time taken to solve
        elapsed_time = time.time() - session.get('start_time', time.time())
        correct_solution = session['solution']
        
        # Check if the solution is correct
        is_correct = user_board == correct_solution
        
        return jsonify({
            'is_correct': is_correct,
            'solution': correct_solution,
            'time_taken': round(elapsed_time, 2),
            'message': 'Congratulations! Your solution is correct.' if is_correct 
                      else 'Sorry, your solution is incorrect.'
        })
    else:
        # If there's no solution in the session, solve the user's board
        board_copy = copy.deepcopy(user_board)
        solve_sudoku(board_copy)
        
        return jsonify({
            'solution': board_copy,
            'message': 'Here is the solution to your Sudoku puzzle.'
        })

@app.route('/check_custom', methods=['POST'])
def check_custom():
    user_board = request.json.get('board')
    
    # Check if the board is valid
    for row in range(9):
        for col in range(9):
            if user_board[row][col] != 0:
                # Temporarily remove the number to check if it's valid
                num = user_board[row][col]
                user_board[row][col] = 0
                if not is_valid(user_board, row, col, num):
                    user_board[row][col] = num
                    return jsonify({
                        'is_valid': False,
                        'message': f'Invalid number {num} at position [{row+1}, {col+1}]'
                    })
                user_board[row][col] = num
    
    # Make a copy and try to solve
    board_copy = copy.deepcopy(user_board)
    if solve_sudoku(board_copy):
        return jsonify({
            'is_valid': True,
            'solution': board_copy,
            'message': 'Here is the solution to your custom Sudoku puzzle.'
        })
    else:
        return jsonify({
            'is_valid': False,
            'message': 'This Sudoku puzzle has no solution.'
        })

if __name__ == '__main__':
    app.run(debug=True)